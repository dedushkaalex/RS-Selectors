components - компоненты со своей логикой
ui - мелкие компоненты, которые не имеют логики. (buttons, div)
core - ядро, тут будут base-components, emitter