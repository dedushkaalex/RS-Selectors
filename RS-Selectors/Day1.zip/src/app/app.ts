import { BaseComponent } from '@/core';

import { HTMLViewer } from '@/components/html-viewer/HTMLViewer';

import { Table } from '@/components';

export class App extends BaseComponent {
  public table;
  public viewer;
  constructor() {
    super({
      tagName: 'div'
    });
    this.table = new Table();
    this.viewer = new HTMLViewer();
  }
}
