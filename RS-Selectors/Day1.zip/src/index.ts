import { Table } from '@components/table/Table';

import { BaseComponent } from '@/core/base-component/BaseComponent';

import '@/styles/global.scss';

import { App } from './app';
import { render } from './core/render';

render(document.getElementById('root') as HTMLElement, new App());
// const table = new Table();
// const div1 = new BaseComponent({
//   tagName: 'div',
//   classList: ['red', 'lysia', 'tasha', 'BossVitalik'],
//   textContent: 'HelloWorld',
//   children: [table]
// });

// console.log(div1.node);

// document.body.append(div1.node);
