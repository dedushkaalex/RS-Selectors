declare module '*.scss' {
  const content: Record<string, string>;
  export default content;
}
declare module '*.css';
declare module '*.png';
declare module '*.jpg';
declare module '*.svg';
