export const CURRENT_LEVEL = 'currentLevel';
