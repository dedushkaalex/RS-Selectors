export const EDITOR_TEXT = `
<code>
<p style="color: green">{</p>
<p>/* Styles would go here. */</p>
<p style="color: green">}</p></br>
<p>/*</p
<p>Type a number to skip to a level.</br>Ex → "5" for level 5</p
<p>*/</p>

</code>
`;
export const EDITOR_HEADING = '<span>CSS Editor</span><span>style.css</span>';
